/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Aluno;
import Model.Turma;
import View.TelaNotas;
import java.awt.Color;
import java.util.ArrayList;

/**
 *
 * @author Thiago Siqueira
 */
public class ControlNotas {

    private ArrayList<Aluno> listaAlunos;
    private ArrayList<Turma> listaTurmas;
    private TelaNotas view;
    private ControlPrincipal ctrPrincipal;

    public ControlNotas(ControlPrincipal pCtrPrincipal){
        ctrPrincipal = pCtrPrincipal;
    }

    public ArrayList<String> turmasStr() {
        ArrayList<String> turma = new ArrayList<>();
        listaTurmas = ctrPrincipal.getCtrTurma().getListaTurma();
        for (Turma t1 : listaTurmas) {
            turma.add(t1.getCurso().getNome() + "." + t1.getCurso().getSemestre() + '-' + t1.getCodigo());
        }

        return turma;
    }

    public void setView(TelaNotas view) {
        this.view = view;
    }
    

    public ArrayList<String[]> getAlunos() {
        ArrayList<String[]> aluno = new ArrayList();
        ArrayList<Aluno> listaAlunosMat = pegaAlunosMat();
        if (listaAlunosMat != null) {
            for (int i = 0; i < listaAlunosMat.size(); i++) {
                String a[] = new String[4];
                a[0] = listaAlunosMat.get(i).getNome();
                a[1] = listaAlunosMat.get(i).getCpf();
                a[2] = Double.toString(listaAlunosMat.get(i).getNotas().getN1());
                a[3] = Double.toString(listaAlunosMat.get(i).getNotas().getN2());
                aluno.add(a);
            }
        }

        return aluno;
    }

    private ArrayList<Aluno> pegaAlunosMat() {
        ArrayList<Aluno> listaAlunosMat = null;
        String t = view.getBoxTurmas().getSelectedItem().toString();
        String[] dadosT = t.split("-");
        System.out.println(dadosT[1]);
        listaTurmas = ctrPrincipal.getCtrTurma().getListaTurma();
        for (Turma turma : listaTurmas) {
            if (turma.getCodigo().equals(dadosT[1])) {
                listaAlunosMat = turma.getListaAlunosTurma();
                System.out.println(listaAlunosMat);
            }
        }
        return listaAlunosMat;
    }

    public void lancarNotas() {
        ArrayList<Aluno> listaAlunosTurma = pegaAlunosMat();
        int indice = view.getTbl_alunos().getSelectedRow();
        String[] aluno = view.getModelo().getAluno(indice);
        for (int i = 0; i < listaAlunosTurma.size(); i++) {
            if (listaAlunosTurma.get(i).getCpf().equals(aluno[1])) {
                double n1 = Double.parseDouble(view.getTxtN1().getText());
                double n2 = Double.parseDouble(view.getTxtN2().getText());
                listaAlunosTurma.get(i).getNotas().setN1(n1);
                listaAlunosTurma.get(i).getNotas().setN2(n2);
                double media = (n1 + n2) / 2;
                if(media < 6.0){
                    view.getTxtMedi().setForeground(Color.red);
                }else{
                    view.getTxtMedi().setForeground(Color.GREEN);
                }
                view.getTxtMedi().setText(Double.toString(media));
            }
        }
    }
}
