    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import View.TelaAluno;
import View.TelaAlunoR;
import View.TelaHistorico;
import View.TelaNotas;
import View.TelaPrincipal;
import View.TelaRelatorioConcluinte;
import View.TelaRelatorioTurma;
import View.TelaTurma;
import View.ViewProfessor;

/**
 *
 * @author Thiago Siqueira
 */
public class ControlPrincipal {

    private ControlAluno ctrAluno;
    private ControlHistorico ctrHistorico;
    private ControlNotas ctrNotas;
    private ControlProfessor ctrProfessor;
    private ControlTurma ctrTurma;
    private ControleAlunoR ctrAlunoR;
    private ControleRelatConcluinte ctrRelatorioC;
    private ControleRelatTurma ctrRelatorioT;

    private TelaPrincipal view;
    private TelaAluno aluno;
    TelaAlunoR alunoR;
    ViewProfessor prof;
    TelaNotas nota;
    TelaTurma turma;
    TelaHistorico historico;
    TelaRelatorioConcluinte concluinte;
    TelaRelatorioTurma RelatTurma;

    //ViewProfessor prof = new ViewProfessor();
    //construtor do controle principal instancia os outros controles
    public ControlPrincipal() {
        view = new TelaPrincipal(this);
        try {
            ctrAluno = new ControlAluno(this);
            ctrTurma = new ControlTurma(this);
            ctrHistorico = new ControlHistorico(this);
            ctrNotas = new ControlNotas(this);
            ctrProfessor = new ControlProfessor();
            ctrTurma = new ControlTurma(this);
            ctrAlunoR = new ControleAlunoR(this);
            ctrRelatorioC = new ControleRelatConcluinte(this);
            ctrRelatorioT = new ControleRelatTurma(this);
        } catch (Exception e) {
        }finally{
            view.setVisible(true);
        }
    }

    //
    
    public void navegarParaCadProf() {
        prof = new ViewProfessor(ctrProfessor);
        ctrProfessor.setView(prof);
        prof.setVisible(true);
    }

    public void navegarParaCadTurma() throws Exception {
        ctrTurma.cadTurma();
        
    }

    public void navegarParaCadAluno() throws Exception {
        aluno = new TelaAluno(this);
        ctrAluno.setView(aluno);
    }

    public void navegarParaRenovar() throws Exception {
        alunoR = new TelaAlunoR(this);
        ctrAlunoR.setView(alunoR);
        alunoR.setVisible(true);
    }

    public void navegarParaNota() throws Exception {
        nota = new TelaNotas(this);
        ctrNotas.setView(nota);
        nota.setVisible(true);
    }

    public void navegarParaHist() throws Exception {
        historico = new TelaHistorico(this);
        ctrHistorico.setView(historico);
        historico.setVisible(true);
    }

    public void navegarParaRelatCon() throws Exception {
        concluinte = new TelaRelatorioConcluinte(this);
        ctrRelatorioC.setView(concluinte);
        concluinte.setVisible(true);
    }

    public void navegarParaRelatTurma() throws Exception {
        RelatTurma = new TelaRelatorioTurma(this);
        ctrRelatorioT.setView(RelatTurma);
        RelatTurma.setVisible(true);
    }

    public ControlAluno getCtrAluno() {
        return ctrAluno;
    }

    public ControlHistorico getCtrHistorico() {
        return ctrHistorico;
    }

    public ControlNotas getCtrNotas() {
        return ctrNotas;
    }

    public ControlProfessor getCtrProfessor() {
        return ctrProfessor;
    }

    public ControlTurma getCtrTurma() {
        return ctrTurma;
    }

    public ControleAlunoR getCtrAlunoR() {
        return ctrAlunoR;
    }

    public ControleRelatConcluinte getCtrRelatorioC() {
        return ctrRelatorioC;
    }

    public ControleRelatTurma getCtrRelatorioT() {
        return ctrRelatorioT;
    }
    
    public void finalize() throws Exception{
        ctrAluno.finalize();
        ctrProfessor.finalize();
        ctrTurma.finalize();
        System.exit(0);
    }
    
    

}
