package Controller;

import Model.Aluno;
import View.TelaHistorico;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

/**
 *
 * @author joaoj
 */
public class ControlHistorico {

    ArrayList<Aluno> listaAlunos = new ArrayList<>();
    private TelaHistorico view;
    private ControlPrincipal ctrPrincipal;

    public ControlHistorico(ControlPrincipal pCtrPrincipal) throws Exception {
        ctrPrincipal = pCtrPrincipal;        
    }

    public void setView(TelaHistorico view) {
        this.view = view;
    }
    
    

    public ArrayList<String> alunosStr() {
        ArrayList<String> alunos = new ArrayList<>();
        listaAlunos = ctrPrincipal.getCtrAluno().getListaAlunos();
        for (Aluno aluno : listaAlunos) {
            alunos.add(aluno.getNome() + "--" + aluno.getCpf());
        }
        return alunos;
    }

    public boolean emitirHistorico() throws IOException {
        String aluno = view.getBoxAluno().getSelectedItem().toString();
        String[] dadosAluno = aluno.split("--");
        System.out.println(aluno);
        for (int i = 0; i < listaAlunos.size(); i++) {
            Aluno alu = listaAlunos.get(i);
            if (alu.getCpf().equals(dadosAluno[1])) {
                view.setAreaHist(leitor(dadosAluno[1]));
                break;
            }

        }
        return false;
    }


    private String leitor(String cpf) throws FileNotFoundException, IOException {
        BufferedReader buffRead = new BufferedReader(new FileReader(cpf + ".txt"));
        String linha = "";
        String aux = "---------";
        while (true) {
            if (linha != null) {
                aux = aux + linha + "\r\n";
 
            } else
                break;
            linha = buffRead.readLine();
        }
        buffRead.close();
        return aux;
    }
    
}
