/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import Model.Professor;
import View.ViewProfessor;

/**
 *
 * @author Thiago Siqueira
 */
public class ControlProfessor {

    private ArrayList<Professor> listaProfessores = new ArrayList<>();
    private ViewProfessor view;

    public ControlProfessor() throws Exception, Exception {
        desserializaProfessor();
    }

    public ArrayList<String[]> getProfessores() {
        ArrayList<String[]> professor = new ArrayList();
        if (listaProfessores != null) {
            for (int i = 0; i < listaProfessores.size(); i++) {
                String a[] = new String[3];
                a[0] = listaProfessores.get(i).getNome();
                a[1] = listaProfessores.get(i).getCPF();
                a[2] = listaProfessores.get(i).getCapacitacao();
                professor.add(a);
            }
        }

        return professor;
    }

    public ArrayList<Professor> getListaProfessores() {
        return listaProfessores;
    }
    
    
    

    /**
     * CRUD - PROFESSOR CREATE, READ, UPDATE, DELETE
     */
    public boolean addProfessor() {
        String nome = view.getTxtNome().getText();
        String cpf = view.getTxt_cpf().getText();
        String curso = view.getBoxCursos().getSelectedItem().toString();
        Professor prof = new Professor(nome, cpf, curso);
        String error = valida(prof);
        if (error.equals("")) {
            listaProfessores.add(prof);
            limparCampos();
            return true;
        } else {
            JOptionPane.showMessageDialog(null, error);
            return false;
        }
    }

    public boolean consProfessor() {
        return true;
    }

    public boolean editProfessor() {
        String cpf = view.getTxt_cpf().getText();
        String curso = view.getBoxCursos().getSelectedItem().toString();
        System.out.println(listaProfessores);
        for (int i = 0; i < listaProfessores.size(); i++) {
            if (cpf.equals(listaProfessores.get(i).getCPF())) {
                listaProfessores.get(i).setCapacitacao(curso);
                return true;
            }
        }
        return false;
    }

    public boolean delProfessor() {
        String cpf = view.getTxt_cpf().getText();
        for (int i = 0; i < listaProfessores.size(); i++) {
            if (listaProfessores.get(i).getCPF().equals(cpf)) {
                listaProfessores.remove(i);
                limparCampos();
                return true;
            }
        }
        return false;
    }

    private String valida(Professor pProf) {
        for (Professor prof : listaProfessores) {
            if (prof.getCPF().equals(pProf.getCPF())) {
                return "CPF já cadastrado no sistema.";
            }
        }

        return "";
    }

    private void limparCampos() {
        view.getTxt_cpf().setText("");
        view.getTxtNome().setText("");
    }

    private void serializaProfessor() throws Exception {
        FileOutputStream objFileOS = new FileOutputStream("professores.dat");
        ObjectOutputStream objOS = new ObjectOutputStream(objFileOS);
        objOS.writeObject(listaProfessores);
        objOS.flush();
        objOS.close();
    }

    private void desserializaProfessor() throws Exception {
        File objFile = new File("professores.dat");
        if (objFile.exists()) {
            FileInputStream objFileIS = new FileInputStream("professores.dat");
            ObjectInputStream objIS = new ObjectInputStream(objFileIS);
            listaProfessores = (ArrayList) objIS.readObject();
            objIS.close();
        }
    }

    public void finalize() throws Exception {
        serializaProfessor();
    }

    public ViewProfessor getView() {
        return view;
    }

    public void setView(ViewProfessor view) {
        this.view = view;
    }

}
