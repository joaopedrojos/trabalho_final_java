/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Responsavel;
import Model.Aluno;
import Model.Nota;
import Model.Turma;
import View.TelaAluno;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author Thiago Siqueira
 */
public class ControlAluno {

    private ArrayList<Aluno> listaAlunos = new ArrayList<>();
    private ArrayList<Turma> listaTurmas;
    private TelaAluno view;
    private ControlPrincipal ctrPrincipal;
    private Aluno aluno;

    public ControlAluno(ControlPrincipal pCtrPrincipal) throws Exception {
        desserializaAluno();
        ctrPrincipal = pCtrPrincipal;
    }

    public ArrayList<Aluno> getListaAlunos() {
        return listaAlunos;
    }

    public ArrayList<String[]> getAlunos() {
        ArrayList<String[]> aluno = new ArrayList();
        if (listaAlunos != null) {
            for (int i = 0; i < listaAlunos.size(); i++) {
                String a[] = new String[6];
                a[0] = listaAlunos.get(i).getNome();
                a[1] = listaAlunos.get(i).getCpf();
                a[2] = listaAlunos.get(i).getEmail();
                a[3] = new SimpleDateFormat("dd/MM/yyyy").format(listaAlunos.get(i).getDataNasc());
                a[4] = "AA";
                a[5] = listaAlunos.get(i).getResp().getNome();
                aluno.add(a);
            }
        }

        return aluno;
    }

    private boolean cadastraAlunoTurma(Aluno al, String curso) {
        listaTurmas = ctrPrincipal.getCtrTurma().getListaTurma();
        for (int i = 0; i < listaTurmas.size(); i++) {
            if (listaTurmas.get(i).getCapTurma() != 0 && listaTurmas.get(i).getCurso().getNome().equals(curso) && listaTurmas.get(i).getCurso().getSemestre() == 1) {
                int capacidade = listaTurmas.get(i).getCapTurma();
                listaTurmas.get(i).addAlunoTurma(al);
                System.out.println(listaTurmas.get(i));
                return true;
            }
        }
        return false;
    }

    private Turma alunoTurma() {
        String cpf = view.getTxtCpf().getText();
        for (int i = 0; i < listaTurmas.size(); i++) {
            ArrayList<Aluno> alunosTurma = listaTurmas.get(i).getListaAlunosTurma();
            for (int j = 0; j < alunosTurma.size(); j++) {
                if (alunosTurma.get(i).getCpf().equals(cpf)) {
                    return listaTurmas.get(i);
                }
            }
        }
        return null;
    }

    public ArrayList<String> alunosSemTurma() {
        ArrayList<String> alunosGeral = new ArrayList<>();
        alunosGeral.add("-- Escolha o aluno --");
        ArrayList<String> alunosMatTurm = new ArrayList<>();
        ArrayList<Turma> listaTurmas = ctrPrincipal.getCtrTurma().getListaTurma();
        listaAlunos = ctrPrincipal.getCtrAluno().getListaAlunos();

        /**
         * PEGAR ALUNOS MATRICULADO *
         */
        for (int i = 0; i < listaTurmas.size(); i++) {
            Turma t1 = listaTurmas.get(i);
            ArrayList<Aluno> alunosMat = t1.getListaAlunosTurma();
            for (int j = 0; j < alunosMat.size(); j++) {
                Aluno al = alunosMat.get(j);
                alunosMatTurm.add(al.getNome() + "--" + al.getCpf());
            }
        }

        for (int i = 0; i < listaAlunos.size(); i++) {
            Aluno al = listaAlunos.get(i);
            alunosGeral.add(al.getNome() + "--" + al.getCpf());
        }

        alunosGeral.removeAll(alunosMatTurm);
        return alunosGeral;
    }

    public ArrayList<String> turmasStr() {
        /* pegar a idade do sujeito e mostrar só as turmas para a sua idade */
        ArrayList<String> turmas = new ArrayList<>();
        String aluno = view.getBoxAlunosSemTurma().getSelectedItem().toString();
        String[] alunosDado = aluno.split("--"); // alunosDado[0] = nome // alunosDado[1] = cpf
        if (!aluno.equals("-- Escolha o aluno --")) {
            Aluno aux = new Aluno();
            for (Aluno al : listaAlunos) {
                if (al.getCpf().equals(alunosDado[1])) {
                    aux = al;
                }
            }

            int idadeAluno = calculaIdade(aux.getDataNasc());

            listaTurmas = ctrPrincipal.getCtrTurma().getListaTurma();

            for (int i = 0; i < listaTurmas.size(); i++) {
                Turma t = listaTurmas.get(i);
                if (idadeAluno <= 12) {
                    if (t.getCurso().getNome().equals("Kids") && t.getCapTurma() != 0 && t.getCurso().getSemestre() == 1) {
                        String ano = Integer.toString(t.getAno());
                        turmas.add(t.getCodigo() + "--" + ano);
                    }
                } else if (idadeAluno >= 13) {
                    if (t.getCurso().getNome().equals("Regular") && t.getCapTurma() != 0 && t.getCurso().getSemestre() == 1) {
                        String ano = Integer.toString(t.getAno());
                        turmas.add(t.getCodigo() + "--" + ano);
                    }
                }
            }

        }
        return turmas;
    }

    private boolean existeAluno() {
        String cpf = view.getTxtCpf().getText();
        for (Aluno aluno : listaAlunos) {
            if (aluno.getCpf().equals(cpf)) {
                return true;
            }

        }
        return false;
    }

    private int calculaIdade(Date nasc) {
        Calendar cData = Calendar.getInstance();
        Calendar cHoje = Calendar.getInstance();

        cData.setTime(nasc);
        cData.set(Calendar.YEAR, cHoje.get(Calendar.YEAR));

        int idade = cData.after(cHoje) ? -1 : 0;
        cData.setTime(nasc);

        idade += cHoje.get(Calendar.YEAR) - cData.get(Calendar.YEAR);

        return idade;
    }

    /**
     *
     * CRUD
     *
     */
    public boolean addAluno() throws ParseException {

        Responsavel resp = new Responsavel();
        String curso = "";

        String nome = view.getTxtNome().getText();
        String email = view.getTxtEmail().getText();
        String cpf = view.getTxtCpf().getText();
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        Date dataFormatada = formato.parse(view.getTxtAnoNasc().getText());
        int idade = calculaIdade(dataFormatada);
        if (idade < 18) {
            String nomeResp = JOptionPane.showInputDialog("Digite o nome do responsável");
            String cpfResp = JOptionPane.showInputDialog("Digite o CPF do responsável");
            resp.setNome(nomeResp);
            resp.setCpf(cpfResp);
        } else {
            resp.setCpf("");
            resp.setNome("");
        }

        if (idade <= 12) {
            curso = "Kids";
        } else {
            curso = "Regular";
        }

        Nota nota = new Nota();
        nota.setN1(0);
        nota.setN2(0);

        if (!existeAluno()) {
            aluno = new Aluno(nome, cpf, email, dataFormatada, resp, nota);

            if (!cadastraAlunoTurma(aluno, curso)) {
                JOptionPane.showMessageDialog(null, "Não há turma disponível para o curso: " + curso);
            }
            listaAlunos.add(aluno);
            return true;
        } else {
            JOptionPane.showMessageDialog(null, "Já existe algum aluno cadastrado com esse CPF!");
            return false;
        }
    }

    public boolean editAluno() {
        String cpf = view.getTxtCpf().getText();
        for (int i = 0; i < listaAlunos.size(); i++) {
            Aluno al = listaAlunos.get(i);
            if (al.getCpf().equals(cpf)) {
                String email = view.getTxtEmail().getText();
                al.setEmail(email);
                return true;
            }
        }
        
        return false;
    }

    public boolean delAluno() {
        String cpf = view.getTxtCpf().getText();
        Turma t1 = alunoTurma();
        for (int i = 0; i < listaAlunos.size(); i++) {
            if (listaAlunos.get(i).getCpf().equals(cpf)) {
                listaAlunos.remove(i);
                if (t1 != null) {
                    t1.setCapTurma(t1.getCapTurma() + 1);
                }
            }
            return true;
        }
        return false;
    }
    
    public boolean matAluno(){
        String aluno = view.getBoxAlunosSemTurma().getSelectedItem().toString();
        String[] dadosA = aluno.split("--"); // dadosA[0] - nome; dadosA[1] - cpf;
        System.out.println(aluno);
        Aluno aux = new Aluno();
        Turma auxt = new Turma();
        for (Aluno a1 : listaAlunos) {
            if(a1.getCpf().equals(dadosA[1])){
                aux = a1;
            }
        }
        ArrayList<Turma> listaTurmas = ctrPrincipal.getCtrTurma().getListaTurma();
        String turmat = view.getBoxTurmasIdade().getSelectedItem().toString();
        String[] dadosT = turmat.split("--"); // dadosA[0] código // dadosA[1] ano
        for (Turma t : listaTurmas) {
            if(t.getCodigo().equals(dadosT[0]) && t.getAno() == Integer.parseInt(dadosT[1])){
                auxt = t;
            }
        }
        
        auxt.addAlunoTurma(aux);
        return true;
    }

    private void serializaAluno() throws Exception {
        FileOutputStream objFileOS = new FileOutputStream("alunos.dat");
        ObjectOutputStream objOS = new ObjectOutputStream(objFileOS);
        objOS.writeObject(listaAlunos);
        objOS.flush();
        objOS.close();
    }

    private void desserializaAluno() throws Exception {
        File objFile = new File("alunos.dat");
        if (objFile.exists()) {
            FileInputStream objFileIS = new FileInputStream("alunos.dat");
            ObjectInputStream objIS = new ObjectInputStream(objFileIS);
            listaAlunos = (ArrayList) objIS.readObject();
            objIS.close();
        }
    }

    public void finalize() throws Exception {
        this.serializaAluno();
    }

    public TelaAluno getView() {
        return view;
    }

    public void setView(TelaAluno view) {
        this.view = view;
    }

}
