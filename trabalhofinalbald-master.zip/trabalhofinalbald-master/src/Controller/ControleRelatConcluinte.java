package Controller;

import Model.Aluno;
import Model.Turma;
import View.TelaRelatorioConcluinte;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

/**
 *
 * @author joaoj
 */
public class ControleRelatConcluinte {

    ArrayList<Turma> listaTurma = new ArrayList<>();
    ArrayList<Aluno> auxiliar = new ArrayList<>();
    private TelaRelatorioConcluinte view;
    private ControlPrincipal ctrPrincipal;

    public ControleRelatConcluinte(ControlPrincipal pCtrPrincipal) throws Exception {
        ctrPrincipal = pCtrPrincipal;
    }

    public void setView(TelaRelatorioConcluinte view) {
        this.view = view;
    }

    public boolean relatConcluintes() {
        String opc = view.getCombo().getSelectedItem().toString();
        String dadosAlu = "";

        for (int i = 0; i < listaTurma.size(); i++) {
            if (listaTurma.get(i).getCurso().getNome().equals(opc)) {
                System.out.println("oi");
                auxiliar = listaTurma.get(i).getListaAlunosTurma();
                for (int j = 0; j < auxiliar.size(); j++) {
                    Aluno alu = auxiliar.get(i);
                    if (alu.getTurmaAtual().getSemestre() == 6/*comparar se semetre é o ultimo do kids*/) {
                        //exibindo os semestres cursados (ano/semestre) 
                        dadosAlu += ("Aluno: " + alu.getNome() + "/nCPF: "
                                + alu.getCpf());
                        //setar informações para dentro do textArea
                        view.getAreaRelat().setText(dadosAlu + "\n");
                    } else if (alu.getTurmaAtual().getCurso().getNome().equals(opc)) {
                        System.out.println("oi 2");
                        if (alu.getTurmaAtual().getSemestre() == 8) {
                            //exibindo os semestres cursados (ano/semestre) 
                            dadosAlu += ("Aluno: " + alu.getNome() + "/nCPF: "
                                    + alu.getCpf());
                            //setar informações para dentro do textArea
                            view.getAreaRelat().setText(dadosAlu + "\n");
                        }
                    }
                }
            }
        }
        return false;
    }

}
