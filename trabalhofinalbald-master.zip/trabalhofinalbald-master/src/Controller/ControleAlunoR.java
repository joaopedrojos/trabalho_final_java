package Controller;

import Model.Aluno;
import Model.Curso;
import Model.Nota;
import Model.Turma;
import View.TelaAlunoR;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.util.ArrayList;
import javax.swing.JOptionPane;

/**
 *
 * @author joaoj
 */
public class ControleAlunoR {

    private TelaAlunoR controller;
    private ControlPrincipal ctrPrincipal;
    private ArrayList<Aluno> listaAlunos;
    private ArrayList<Turma> listaTurmas;
    //ControlAluno ctr;
    private TelaAlunoR view;

    public void setView(TelaAlunoR view) {
        this.view = view;
    }

    public ControleAlunoR(ControlPrincipal pCtrPrincipal) {
        ctrPrincipal = pCtrPrincipal;
    }

    public ArrayList<String> alunosStr() {
        ArrayList<String> alunos = new ArrayList<>();
        listaTurmas = ctrPrincipal.getCtrTurma().getListaTurma();
        //listaAlunos = ctrPrincipal.getCtrAluno().getListaAlunos();
        for(int i = 0; i < listaTurmas.size(); i++){
            Turma t = listaTurmas.get(i);
            ArrayList<Aluno> alunosMat = t.getListaAlunosTurma();
            for(int j = 0; j < alunosMat.size(); j++){
                Aluno al = alunosMat.get(j);
                alunos.add(al.getNome() + "--" + al.getCpf());
            }
        }

        return alunos;
    }

    public void renovaMatricula() throws IOException {
        String alunoSelecionado = view.getBoxAluno().getSelectedItem().toString();
        System.out.println(alunoSelecionado);
        String[] dados = alunoSelecionado.split("--");
        String situacao = "";
        System.out.println(dados[1]);
        if (turmaDoAluno(dados[1])) {
            JOptionPane.showMessageDialog(null, "Matricula foi renovada com sucesso!");
        } else {
            JOptionPane.showMessageDialog(null, "Ops, caimos no lugar errado, ocorreu falha :(");
        }
    }

    private boolean turmaDoAluno(String cpf) throws IOException {
        listaTurmas = ctrPrincipal.getCtrTurma().getListaTurma();
        for(int i = 0; i < listaTurmas.size(); i++){
            Turma t = listaTurmas.get(i);
            System.out.println(t);
            ArrayList<Aluno> listaMatriculados = t.getListaAlunosTurma();
            for(int j = 0; j < listaMatriculados.size(); j++){
                Aluno a = listaMatriculados.get(j);
                if(a.getCpf().equals(cpf)){
                    System.out.println("Achamos o aluno");
                    return true;
                }
            }
        }
        return false;
    }

    private void escritor(String out, String cpf) throws IOException {
        BufferedWriter buffWrite = new BufferedWriter(new FileWriter(cpf + ".txt", true));
        buffWrite.append(out);
        buffWrite.close();
    }

}
