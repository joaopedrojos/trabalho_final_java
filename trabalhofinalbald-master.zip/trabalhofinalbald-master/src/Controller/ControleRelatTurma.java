package Controller;

import Model.Aluno;
import Model.Turma;
import View.TelaRelatorioConcluinte;
import View.TelaRelatorioTurma;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

/**
 *
 * @author joaoj
 */
public class ControleRelatTurma {

    ArrayList<Turma> listaTurmas;
    private TelaRelatorioTurma view;
    private ControlPrincipal ctrPrincipal;

    public ControleRelatTurma(ControlPrincipal pCtrPrincipal) throws Exception {
        ctrPrincipal = pCtrPrincipal;
    }

    public ArrayList<String> turmasStr() {
        ArrayList<String> alunos = new ArrayList<>();
        listaTurmas = ctrPrincipal.getCtrTurma().getListaTurma();
        for (Turma turma : listaTurmas) {
            alunos.add(turma.getCodigo());
        }
        return alunos;
    }

    public void setView(TelaRelatorioTurma view) {
        this.view = view;
    }
    
    

    public boolean emitirRelatTurma() {

        return false;
    }

    //retorna alunos da turma
    public ArrayList<String[]> getAlunosTurma() {
        ArrayList<String[]> turma = new ArrayList();
        ArrayList<Aluno> auxiliar = new ArrayList<>();
        listaTurmas = ctrPrincipal.getCtrTurma().getListaTurma();
        if (listaTurmas != null) {
            for (int i = 0; i < listaTurmas.size(); i++) {
                if (listaTurmas.get(i).getCodigo().equals(view.getComboTurma().getSelectedItem().toString())) {
                    auxiliar = listaTurmas.get(i).getListaAlunosTurma();
                    for (int j = 0; j < auxiliar.size(); j++) {
                        String a[] = new String[7];
                        a[0] = auxiliar.get(i).getNome();
                        a[1] = auxiliar.get(i).getCpf();
                        a[2] = Double.toString(auxiliar.get(i).getNotas().getN1());
                        a[3] = Double.toString(auxiliar.get(i).getNotas().getN2());
                        double media = auxiliar.get(i).getNotas().getMedia();
                        a[4] = Double.toString(media);
                        if(media >= 6.0){
                            a[5] = "Aprovado";
                        }else if(media < 6.0){
                            a[5] = "Reprovado";
                        }
                        a[6] = Integer.toString(auxiliar.get(i).getTurmaAtual().getSemestre());
                        turma.add(a);
                    }
                }

            }
        }
        return turma;
    }

}
