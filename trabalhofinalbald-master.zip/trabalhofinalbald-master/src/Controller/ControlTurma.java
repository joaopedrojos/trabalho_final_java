/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Curso;
import Model.Turma;
import Model.Professor;
import View.TelaTurma;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;

/**
 *
 * @author Thiago Siqueira
 */
public class ControlTurma {

    private ArrayList<Turma> listaTurma = new ArrayList<>();
    private ArrayList<Professor> listaProfessor;
    private TelaTurma view;
    private ControlPrincipal ctrPrincipal;

    public ControlTurma(ControlPrincipal pCtrPrincipal) throws Exception {
        desserializaTurma();
        ctrPrincipal = pCtrPrincipal;
    }
    
    public void cadTurma() throws Exception{
        view = new TelaTurma(ctrPrincipal);
        view.setVisible(true);
    }

    public boolean addTurma(){
        int semestre = Integer.parseInt(view.getBoxSemestre().getSelectedItem().toString());
        int ano = Integer.parseInt(view.getTxtAno().getText());
        int capacidade = Integer.parseInt(view.getTxtCapacidade().getText());
        String periodo = view.getComboPeriodo().getSelectedItem().toString();
        int diaSemana = view.getComboDia().getSelectedIndex() + 2;
        String aula = pegaAulaSelecionadas();
        String curso = view.getBoxCursos().getSelectedItem().toString();

                
        Professor respProf = catchProf(view.getBoxProfessor().getSelectedItem().toString());
        int semestreCurso = Integer.parseInt(view.getBoxCursoSemestre().getSelectedItem().toString());
        String codigo = Integer.toString(diaSemana) + periodo.charAt(0) + aula + curso.charAt(0) + Integer.toString(semestreCurso);
        Curso c1 = new Curso(curso, semestreCurso);
        Turma t1 = new Turma(codigo, semestre, ano, capacidade, codigo, c1, respProf);
        listaTurma.add(t1);
        System.out.println(t1);
        view.getTxtCode().setText(codigo);
        return true;
    }
   

    public ArrayList<String[]> getTurmas() {
        ArrayList<String[]> turmas = new ArrayList();
        if (listaTurma != null) {
            for (int i = 0; i < listaTurma.size(); i++) {
                String a[] = new String[2];
                a[0] = listaTurma.get(i).getCurso().getNome();
                a[1] = listaTurma.get(i).getCodigo();
                turmas.add(a);
            }
        }

        return turmas;
    }

    public ArrayList<String> professorStr(String curso) {
        ArrayList<String> professor = new ArrayList<>();
        listaProfessor = ctrPrincipal.getCtrProfessor().getListaProfessores();
        for (Professor prof : listaProfessor) {
            if (prof.getCapacitacao().equals(curso)) {
                professor.add(prof.getNome());
            }else if(prof.getCapacitacao().equals("Ambos")){
                professor.add(prof.getNome());
            }
        }

        return professor;
    }
    
    public ArrayList<String> semestreStr(){
        int i = 0;
        String curso = view.getBoxCursos().getSelectedItem().toString();
        if(curso.equals("Kids")){
            i = 6;
        }else if(curso.equals("Regular")){
            i = 8;
        }else{
            i = -1;
        }
        
        ArrayList<String> semestre = new ArrayList<>();
        for(int j = 1; j <= i; j++){
            semestre.add(Integer.toString(j));
        }
        
        return semestre;
    }

    private Professor catchProf(String nomeProf) {
        listaProfessor = ctrPrincipal.getCtrProfessor().getListaProfessores();
        for (Professor professor : listaProfessor) {
            if (professor.getNome().equals(nomeProf)) {
                return professor;
            }
        }
        return null;
    }

    private String pegaAulaSelecionadas() {
        String aula = "";
        if (view.getCb1().isSelected()) {
            aula += "1";
        }
        if (view.getCb2().isSelected()) {
            aula += "2";
        }
        if (view.getCb3().isSelected()) {
            aula += "3";
        }
        if (view.getCb4().isSelected()) {
            aula += "4";
        }
        return aula;

    }

    public ArrayList<Turma> getListaTurma() {
        return listaTurma;
    }

    public void setView(TelaTurma view) {
        this.view = view;
    }
    
    
    
    private void desserializaTurma() throws Exception {
        File objFile = new File("turmas.dat");
        if (objFile.exists()) {
            FileInputStream objFileIS = new FileInputStream("turmas.dat");
            ObjectInputStream objIS = new ObjectInputStream(objFileIS);
            listaTurma = (ArrayList) objIS.readObject();
            objIS.close();
        }
    }

    private void serializaTurma() throws Exception {
        FileOutputStream objFileOS = new FileOutputStream("turmas.dat");
        ObjectOutputStream objOS = new ObjectOutputStream(objFileOS);
        objOS.writeObject(listaTurma);
        objOS.flush();
        objOS.close();
    }
    
    public void finalize() throws Exception{
        this.serializaTurma();
    }

}
