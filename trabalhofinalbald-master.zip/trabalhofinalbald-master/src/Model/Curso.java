/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.Serializable;

/**
 *
 * @author Thiago Siqueira
 */
public class Curso implements Serializable {
    
    private String nome;
    private int semestre;

    public Curso(String nome, int semestre) {
        this.nome = nome;
        this.semestre = semestre;
    }
    
    public Curso(){
        
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getSemestre() {
        return semestre;
    }

    public void setSemestre(int semestre) {
        this.semestre = semestre;
    }

    @Override
    public String toString() {
        return "Curso{" + "nome=" + nome + ", semestre=" + semestre + '}';
    }
    
    
    
    
}
