/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author Thiago Siqueira
 */
public class Aluno implements Serializable {

    private String nome;
    private String cpf;
    private String email;
    private Date dataNasc;
    private Responsavel resp;
    private Nota notas;
    //private Curso turmaAtual;
    private Turma turmaAtual;
    
    public Aluno(String nome, String cpf, String email, Date dataNasc, Responsavel resp, Nota pNota) {
        this.nome = nome;
        this.cpf = cpf;
        this.email = email;
        this.dataNasc = dataNasc;
        this.resp = resp;
        this.notas = pNota;
    }

    public Aluno() {

    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getDataNasc() {
        return dataNasc;
    }

    public void setDataNasc(Date dataNasc) {
        this.dataNasc = dataNasc;
    }

    public Responsavel getResp() {
        return resp;
    }

    public void setResp(Responsavel resp) {
        this.resp = resp;
    }

    public Nota getNotas() {
        return notas;
    }

    public void setNotas(Nota notas) {
        this.notas = notas;
    }

    public Turma getTurmaAtual() {
        return turmaAtual;
    }

    public void setTurmaAtual(Turma turmaAtual) {
        this.turmaAtual = turmaAtual;
    }

    @Override
    public String toString() {
        return "Aluno{" + "nome=" + nome + ", cpf=" + cpf + ", email=" + email + ", dataNasc=" + dataNasc + ", resp=" + resp + ", notas=" + notas + '}';
    }


    
    

}
