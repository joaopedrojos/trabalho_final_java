package Model;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author joaoj
 */
public class Turma implements Serializable{

    private String codigo;
    private int semestre;
    private int ano;
    private int capTurma;//capacidade maxima de alunos na Turma
    private String horario;//modelo Unifei
    private Curso curso; //Sin 2019.2
    private Professor respProf;
    private ArrayList<Aluno> listaAlunosTurma = new ArrayList<>();

    public Turma(String codigo, int semestre, int ano, int capTurma, String horario, Curso curso, Professor respProf) {
        this.codigo = codigo;
        this.semestre = semestre;
        this.ano = ano;
        this.capTurma = capTurma;
        this.horario = horario;
        this.curso = curso;
        this.respProf = respProf;
    }
        
    public Turma(){
        
    }
    
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public int getSemestre() {
        return semestre;
    }

    public void setSemestre(int semestre) {
        this.semestre = semestre;
    }

    public int getAno() {
        return ano;
    }

    public void setAno(int ano) {
        this.ano = ano;
    }

    public int getCapTurma() {
        return capTurma;
    }

    public void setCapTurma(int capTurma) {
        this.capTurma = capTurma;
    }

    public String getHorario() {
        return horario;
    }

    public void setHorario(String horario) {
        this.horario = horario;
    }

    public Professor getRespProf() {
        return respProf;
    }

    public void setRespProf(Professor respProf) {
        this.respProf = respProf;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    public ArrayList<Aluno> getListaAlunosTurma() {
        return listaAlunosTurma;
    }

    public void setListaAlunosTurma(ArrayList<Aluno> listaAlunosTurma) {
        this.listaAlunosTurma = listaAlunosTurma;
    }
    
    public void addAlunoTurma(Aluno al){
        listaAlunosTurma.add(al);
        this.setCapTurma(capTurma - 1);
    }

    @Override
    public String toString() {
        return "Turma{" + "codigo=" + codigo + ", semestre=" + semestre + ", ano=" + ano + ", capTurma=" + capTurma + ", horario=" + horario + ", curso=" + curso + ", respProf=" + respProf + ", listaAlunosTurma=" + listaAlunosTurma + '}';
    }
    
    
    


}
