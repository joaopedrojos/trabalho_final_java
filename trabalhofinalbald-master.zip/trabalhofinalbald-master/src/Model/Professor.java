/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.io.Serializable;

/**
 *
 * @author thiag
 */
public class Professor implements Serializable {

    private String nome;
    private String CPF;
    private String capacitacao;

    public Professor(String nome, String CPF, String capacitacao) {
        this.nome = nome;
        this.CPF = CPF;
        this.capacitacao = capacitacao;
    }

    public Professor() {

    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCPF() {
        return CPF;
    }

    public void setCPF(String CPF) {
        this.CPF = CPF;
    }

    public String getCapacitacao() {
        return capacitacao;
    }

    public void setCapacitacao(String capacitacao) {
        this.capacitacao = capacitacao;
    }
    
    

}
