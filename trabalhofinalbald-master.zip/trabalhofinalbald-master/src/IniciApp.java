
import Controller.ControlPrincipal;

public class IniciApp {

    public static void main(String[] args) {
        ControlPrincipal cp = new ControlPrincipal();
    }
}
