# trabalhofinalcom220
Repositório criado para o trabalho final da disciplina COM220 - Computação Orientada a Objetos.

***

A escola de inglês Easy English contratou seu grupo para desenvolver um sistema para
controle acadêmico, de forma a facilitar a gerência da escola. A Easy English oferece
dois tipos de curso:
* Kids: para crianças de até 12 anos de idade. Este curso tem duração de 6 semestres.
Cada semestre é identificado pela letra K e por um número sequencial que identifica
o semestre. Por exemplo, o terceiro semestre é o K3. Ao concluir o curso, o aluno
recebe o Certificado Kids e pode ingressar no quinto semestre do curso Regular.
* Regular: para adultos e adolescentes a partir de 13 anos de idade. Este curso tem
duração de 8 semestres. Ao concluir o curso, o aluno recebe o Certificado Easy
English.
O sistema de controle acadêmico da Easy English deve permitir:
1) Cadastrar professores, com nome e CPF, indicando os cursos nos quais são capazes
de atuar (Kids, Regular ou ambos).
2) Criar turmas, indicando o código, o semestre (1 ou 2), o ano, a capacidade da turma
(número máximo de alunos), o horário (usar esquema da UNIFEI, com apenas uma
aula semanal), o curso/semestre e o professor responsável. O código da turma é
dado pela identificação do horário + a identificação do curso/semestre. Por exemplo,
uma turma do curso K3 ministrada nos dois primeiros horários da noite da quarta
feira fica 4N12K3.
3) Matricular um aluno em uma turma existente.
* Na primeira matrícula (matrícula nova), o aluno deve ter seus dados cadastrados
(nome, CPF, email, data de nascimento). Se menor de idade, o sistema deve
ainda solicitar o nome do responsável (pai, mãe, outro) e o CPF do responsável.
Na primeira matrícula o aluno deve, obrigatoriamente, ser matriculado no
primeiro semestre do curso Kids se tiver até 12 anos, ou no primeiro semestre do
curso Regular se tiver 13 anos ou mais.
* Na renovação de matrícula, o sistema deve checar o curso do aluno e qual foi o
último semestre cursado com aprovação. A matrícula deve ser feita no semestre
seguinte. Por exemplo, se a última aprovação do aluno aconteceu no
curso/semestre R3, o aluno deve ser matriculado em R4. No caso de alunos que
concluíram o curso Kids (última matrícula com aprovação foi em K6), a nova
matrícula deve ser no quinto semestre do curso Regular, ou seja, R5.
* A matrícula só pode ser efetivada se houver vaga na turma. Quando algum aluno
solicitar matrícula em uma turma lotada, o funcionário responsável pela
matrícula deve criar uma nova turma para atender o aluno.
4) Lançar notas: o sistema deve permitir que a secretária lance duas notas para cada
turma oferecida. Ao selecionar a opção de lançar notas, a secretária deve poder
escolher a turma. Em seguida, deve poder selecionar a nota (N1 ou N2) a ser
lançada. O sistema deve exibir a listagem de alunos da turma com um campo de
texto para o lançamento da nota de cada aluno. No final deve haver dois botões: 
Salva e Cancela. A mesma tela que permite lançar notas deve permitir alterar notas
já lançadas. Neste caso, as notas existentes devem ser mostradas nos campos de
texto, permitindo a alteração. Ao clicar no botão Salva a alteração é efetivada.
5) Emitir histórico: o sistema deve ser capaz de emitir o histórico de um aluno, a partir
de seu CPF, exibindo os semestres cursados (ano/semestre) , o nome do curso/
semestre e a nota obtida no semestre.
6) Emitir relatórios de concluintes: o sistema deve emitir dois relatórios de concluintes:
o primeiro mostrando o nome e o CPF de todos os alunos que estão matriculados no
último semestre do curso Kids e o segundo mostrando os mesmos dados dos alunos
que estão matriculados no último semestre do curso Regular.
7) Emitir relatório de turma: a partir do código da turma, deve ser possível obter um
relatório com os dados dos alunos (CPF e nome) e com as notas existentes. Se
houver apenas uma nota lançada, a mesma deve ser mostrada. Se as duas notas já
tiverem sido lançadas, o sistema deve mostra-las e calcular e exibir a média
aritmética das notas, informando quais alunos estão aprovados e quais estão
reprovados. A média necessária para aprovação é seis.
